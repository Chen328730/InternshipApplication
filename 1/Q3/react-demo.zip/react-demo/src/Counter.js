import React, { useState } from "react";

function Counter() {
  // Save count status
  const [count, setCount] = useState(0);

  // Handle button click
  const handleClick = () => {
    setCount(count + 1);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <p style={{ fontSize: "24px" }}>Current count: {count}</p>
      <button
        onClick={handleClick}
        style={{
          fontSize: "20px",
          padding: "10px 20px",
          borderRadius: "8px",
          cursor: "pointer",
        }}
      >
        +1
      </button>
    </div>
  );
}

export default Counter;
